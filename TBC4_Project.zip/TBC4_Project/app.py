from flask import Flask, request, jsonify
from pymongo import MongoClient
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS if you need it for frontend communication

# Connect to MongoDB
client = MongoClient('mongodb+srv://zubiyanshaikh:Zubiyan%40123@cluster0.fsovat3.mongodb.net/')
db = client["Login"]
collection3 = db["Finance_Data"]  # Collection name

db2 = client['timesheet_db']
collection2 = db2['timesheets']

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")

    # Special condition for Finance user
    if username == "finance" and password == "123":
        return jsonify({"message": "Login successful", "redirect": "finance_page.html"}), 200

    # Access the Finance collection in MongoDB for other users
    users = db["Finance_Login"]
    user = users.find_one({"username": username, "password": password})
    
    if user:
        return jsonify({"message": "Login successful", "redirect": "faculty.html"}), 200
    else:
        return jsonify({"message": "Invalid username/password"}), 400
    
@app.route('/get_timesheets', methods=['GET'])
def get_timesheets():
    try:
        # Access the timesheet_db collection
        db = client['timesheet_db']
        timesheets = db["timesheets"]

        # Initialize an empty list to store processed records
        records = []

        # Fetch all documents from the collection
        cursor = timesheets.find({}, {"_id": 0, "username": 1, "startDate": 1, "endDate": 1, "week1": 1})

        # Process each document in the cursor
        for doc in cursor:
            # Extract general fields
            username = doc.get("username", "")
            startDate = doc.get("startDate", "")
            endDate = doc.get("endDate", "")

            # Process the week1 array
            for entry in doc.get("week1", []):
                record = {
                    "username": username,
                    "courseCode": entry.get("courseCode", ""),
                    "date": entry.get("date", ""),
                    "hoursWorked": entry.get("hoursWorked", ""),
                }
                records.append(record)

        # Return the processed records
        if records:
            return jsonify({"message": "Timesheet data retrieved successfully", "data": records}), 200
        else:
            return jsonify({"message": "No timesheet data found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/submit_timesheet', methods=['POST'])
def submit_timesheet():
    # Get the data from the request
    timesheet_data = request.json

    if not timesheet_data:
        return jsonify({"error": "No data provided"}), 400

    # Ensure the username is present in the timesheet data
    username = timesheet_data.get("username")
    if not username:
        return jsonify({"error": "Username is required"}), 400

    # Add the username to the timesheet data
    timesheet_data["username"] = username

    # Access the timesheet collection in MongoDB
    try:
        # Insert the timesheet data (which now includes the username)
        collection2.insert_one(timesheet_data)
        return jsonify({"message": "Timesheet submitted successfully"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route('/get_financedata', methods=['GET'])
def get_finance_data():
    try:
        # Fetch documents with only the required fields
        data = list(collection3.find({}, {
            "_id": 0,  # Exclude the _id field
            "Subject": 1,
            "Instructor": 1,
            "Weekday": 1,
            "Scheduled_Hours": 1
        }))
        
        return jsonify({
            "message": "Finance data retrieved successfully" if data else "No finance data found",
            "data": data
        }), 200 if data else 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@app.route('/compare_data', methods=['GET'])
def compare_data():
    try:
        # Access the collections
        db = client['Login']
        finance_data = db['Finance_Data']
        timesheets = db2['timesheets']

        # Fetch all data from Finance_Data
        finance_records = list(finance_data.find({}, {
            "_id": 0,
            "Subject": 1,
            "Instructor": 1,
            "Weekday": 1,
            "Scheduled_Hours": 1
        }))

        # Fetch all timesheet data
        timesheet_records = []
        cursor = timesheets.find({}, {
            "_id": 0, 
            "username": 1, 
            "week1": 1
        })

        for doc in cursor:
            username = doc.get("username", "")
            for entry in doc.get("week1", []):
                timesheet_records.append({
                    "username": username,
                    "courseCode": entry.get("courseCode", ""),
                    "date": entry.get("date", ""),
                    "hoursWorked": entry.get("hoursWorked", "")
                })

        # Match data between the two collections
        results = []
        for timesheet in timesheet_records:
            matched = False
            for finance in finance_records:
                if (
                    timesheet["username"] == finance["Instructor"] and
                    timesheet["courseCode"] == finance["Subject"] and
                    timesheet["date"] == finance["Weekday"] and
                    timesheet["hoursWorked"] == finance["Scheduled_Hours"]
                ):
                    matched = True
                    break

            results.append({
                "username": timesheet["username"],
                "courseCode": timesheet["courseCode"],
                "date": timesheet["date"],
                "hoursWorked": timesheet["hoursWorked"],
                "status": "RIGHT" if matched else "WRONG"
            })

        return jsonify({
            "message": "Data comparison completed",
            "results": results
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500



if __name__ == '__main__':
    app.run(debug=True)
